$(document).ready(function() {
    $('#downloadForm').on('submit', function(event) {
        event.preventDefault();
        var formData = $(this).serialize();

        $.ajax({
            url: 'convert',
            type: 'POST',
            data: formData,
            success: function(response) {
                $('#message').html('<div class="alert alert-success">Conversion exitosa. <a href="/downloads/' + response.filename + '">Descargar MP3</a></div>');
            },
            error: function(response) {
                $('#message').html('<div class="alert alert-danger">Ocurrió un error durante la conversión. Inténtalo de nuevo.</div>');
            }
        });
    });
});
